import requests
import wikipedia
from rich import print
from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table
from rich.live import Live
import pyfiglet
import readchar
from googletrans import Translator
import random

console = Console()
wikipedia.set_lang("id")
translator = Translator()

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36"
}

def baca_artikel():
    console.clear()
    console.print("[bold green]Masukkan judul artikel Wikipedia:[/]")
    query = console.input(">>> ")
    try:
        summary = wikipedia.summary(query, sentences=5)
        console.clear()
        console.print(Panel.fit(summary, title=f"[bold cyan]{query}[/bold cyan]", border_style="green"))
    except wikipedia.exceptions.DisambiguationError as e:
        console.print(f"[bold red]Terlalu banyak hasil![/] Coba lebih spesifik.\n[dim]{e.options}[/dim]")
    except wikipedia.exceptions.PageError:
        console.print("[bold red]Artikel tidak ditemukan.[/]")
    console.input("\n[bold yellow]Tekan Enter untuk kembali ke menu...[/]")

def kamus():
    console.clear()
    console.print("[bold green]Masukkan kata dalam Bahasa Inggris:[/]")
    kata = console.input(">>> ").strip().lower()
    url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{kata}"

    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200:
            data = r.json()[0]
            hasil = f"[bold cyan]Arti kata: [/] [green]{data['word']}[/]\n"
            for meaning in data['meanings']:
                hasil += f"\n[bold magenta]({meaning['partOfSpeech']})[/]"
                for d in meaning['definitions'][:2]:
                    hasil += f"\n → {d['definition']}"
            console.clear()
            console.print(Panel.fit(hasil.strip(), title=f"[bold cyan]Kamus: {kata}[/bold cyan]", border_style="green"))
        else:
            console.print(f"[bold red]Kata tidak ditemukan di kamus.[/]")
    except Exception as e:
        console.print(f"[bold red]Terjadi kesalahan saat mengambil data:[/] {e}")

    console.input("\n[bold yellow]Tekan Enter untuk kembali ke menu...[/]")

def kalkulator():
    console.clear()
    console.print("[bold green]Masukkan ekspresi matematika (gunakan operator + - * / dan angka):[/]")
    expr = console.input(">>> ")
    try:
        if any(c not in "0123456789+-*/.() " for c in expr):
            raise ValueError("Hanya boleh angka dan operator matematika.")
        result = eval(expr, {"__builtins__": {}})
        console.print(Panel.fit(f"Hasil: [bold cyan]{result}[/bold cyan]", title="Kalkulator", border_style="blue"))
    except Exception as e:
        console.print(f"[bold red]Ekspresi tidak valid:[/] {e}")
    console.input("\n[bold yellow]Tekan Enter untuk kembali ke menu...[/]")

ascii_banner = pyfiglet.figlet_format("Delearn", font="big")
ascii_with_author = f"{ascii_banner}\n[bold green]Author:[/] [yellow]@Dekurity[/yellow]"
panel_banner = Panel.fit(ascii_with_author, title="[bold magenta]Delearn[/bold magenta]", border_style="cyan")

menu_items = [
    "1. Baca Artikel",
    "2. Kamus",
    "3. Kalkulator",
    "4. Keluar"
]
selected_index = 0

def render():
    table = Table.grid()
    table.add_column()
    for i, item in enumerate(menu_items):
        table.add_row(f"[black on cyan]{item}[/]" if i == selected_index else item)
    panel_menu = Panel.fit(table, title="[bold green]Menu Pilihan[/bold green]", border_style="white")
    return Group(panel_banner, panel_menu)

while True:
    with Live(render(), console=console, refresh_per_second=10, screen=True) as live:
        while True:
            key = readchar.readkey()
            if key == readchar.key.UP:
                selected_index = (selected_index - 1) % len(menu_items)
            elif key == readchar.key.DOWN:
                selected_index = (selected_index + 1) % len(menu_items)
            elif key in (readchar.key.ENTER, readchar.key.CR):
                break
            live.update(render())

    console.clear()
    console.print(panel_banner)
    choice = menu_items[selected_index]

    if "Baca Artikel" in choice:
        baca_artikel()
    elif "Kamus" in choice:
        kamus()
    elif "Kalkulator" in choice:
        kalkulator()
    elif "Keluar" in choice:
        console.print("\n[bold red]Keluar dari program...[/]")
        break
