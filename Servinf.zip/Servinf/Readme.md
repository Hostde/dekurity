Tutorial dan Informasi Servinf (Server Info Tech)

Servinf adalah alat CLI berbasis Python yang membantu Anda mendapatkan informasi lengkap tentang server atau domain secara cepat dan interaktif. Dokumentasi ini berfungsi sebagai panduan tutorial dan referensi informasi, bukan untuk penggunaan GitHub.


---

1. Gambaran Umum

Dengan Servinf, Anda dapat:

Melihat Identitas Server: Domain, alamat IP.

GeoIP Lookup: Mengetahui lokasi fisik, ISP, dan zona waktu.

DNS Records: Mengambil record A, AAAA, MX, NS, TXT, dan CNAME.

WHOIS: Informasi pendaftar, tanggal pembuatan, dan tanggal kedaluwarsa.

HTTP Headers: Status kode dan detail header HTTP.

SSL Certificate: Informasi dasar dan detail sertifikat (issuer, tanggal validasi, serial).

Port Scanner: Mendeteksi port umum yang terbuka (FTP, SSH, HTTP, HTTPS, MySQL, dll.).

WAF/Firewall Detection: Deteksi keberadaan Web Application Firewall seperti Cloudflare, Sucuri, ModSecurity, dll., melalui manipulasi User-Agent.

Ping & Traceroute: Uji konektivitas (4 paket ping) dan pelacakan rute jaringan.



---

2. Persiapan Lingkungan

Sebelum menjalankan Servinf, pastikan:

1. Anda memiliki Python 3 terinstal di sistem.


2. Tersedia perintah ping di terminal (umumnya sudah bawaan).


3. (Opsional) Perintah traceroute terpasang jika ingin menggunakan fitur traceroute.




---

3. Instalasi Dependensi

Jalankan perintah berikut di terminal untuk menginstal library yang diperlukan:

pip install rich pyfiglet requests dnspython python-whois

rich: Untuk tampilan tabel, panel, dan progress bar.

pyfiglet: Untuk membuat banner ASCII art.

requests: Untuk permintaan HTTP dan deteksi WAF.

dnspython: Untuk query DNS.

python-whois: Untuk informasi WHOIS domain.



---

4. Menjalankan Servinf

1. Simpan kode Python sebagai servinf.py.


2. Buka terminal di folder tersebut.


3. Jalankan:

python servinf.py


4. Masukkan domain atau IP saat diminta, misalnya:

Masukkan domain atau IP: example.com


5. Tunggu proses progress bar hingga selesai.




---

5. Penjelasan Output

Setelah proses selesai, Servinf akan menampilkan beberapa bagian informasi secara berurutan:

1. Identitas: Domain dan IP.


2. GeoIP Information: Lokasi, ISP, koordinat, dan zona waktu.


3. HTTP Headers: Status code dan header HTTP.


4. SSL Certificate (Basic): Issuer dan masa berlaku.


5. DNS Records: Daftar record DNS per tipe.


6. WHOIS Information: Data pendaftar domain.


7. Open Ports: Port umum yang terbuka.


8. Firewall/WAF Detection: Nama WAF jika terdeteksi.


9. Ping Result: Hasil 4 paket ping.


10. Traceroute Result: Jalur jaringan ke server.


11. SSL Certificate (Detailed): Issuer, valid from, valid until, dan serial number.




---

6. Opsi Kustomisasi

Batch Mode: Tambahkan opsi --batch <file.txt> untuk memproses banyak domain sekaligus.

Export Hasil: Implementasikan fungsi untuk menyimpan output ke format .json, .txt, atau .xlsx.

Timeout: Sesuaikan nilai timeout di fungsi HTTP dan socket jika diperlukan.

Port Range: Ubah daftar common_ports atau tambahkan opsi untuk scan range custom.

User-Agent: Tambahkan atau modifikasi daftar headers_list untuk deteksi WAF yang lebih luas.



---

7. Tips dan Trik

Gunakan di jaringan lokal atau server remote melalui SSH.

Kombinasikan hasil dengan monitoring tools lain untuk analisis mendalam.

Jalankan secara berkala (cronjob) untuk memantau perubahan konfigurasi.



---

Terima kasih telah menggunakan Servinf! Jika ada pertanyaan atau masukan, silakan catat di dokumentasi Anda sendiri.

