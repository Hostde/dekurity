#!/usr/bin/env python3
import os
import subprocess
import threading
import socket
import ssl
import requests
import whois
import dns.resolver
from rich import print
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress
import pyfiglet

console = Console()

def banner():
    ascii_banner = pyfiglet.figlet_format("Servinf")
    console.print(Panel(ascii_banner, style="bold cyan", title="Server Info Tech"))

def get_ip(domain):
    try:
        return socket.gethostbyname(domain)
    except:
        return "N/A"

def geoip(ip):
    try:
        res = requests.get(f"https://ipinfo.io/{ip}/json", timeout=5)
        return res.json()
    except:
        return {}

def get_headers(domain):
    try:
        res = requests.get(f"http://{domain}", timeout=5)
        return res.status_code, res.headers
    except:
        return "Timeout", {}

def ssl_info(domain):
    ctx = ssl.create_default_context()
    try:
        with ctx.wrap_socket(socket.socket(), server_hostname=domain) as s:
            s.settimeout(5)
            s.connect((domain, 443))
            cert = s.getpeercert()
            return {
                "issuer": cert.get('issuer'),
                "valid_from": cert.get('notBefore'),
                "valid_to": cert.get('notAfter')
            }
    except:
        return {}

def get_dns(domain):
    records = {}
    types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME']
    for rtype in types:
        try:
            answers = dns.resolver.resolve(domain, rtype)
            records[rtype] = [str(r.to_text()) for r in answers]
        except:
            records[rtype] = []
    return records

def get_whois(domain):
    try:
        info = whois.whois(domain)
        return {
            "domain": info.domain_name,
            "registrar": info.registrar,
            "created": info.creation_date,
            "expires": info.expiration_date,
            "emails": info.emails
        }
    except:
        return {}

# --- Port scanner ---
common_ports = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS",
    587: "SMTP (TLS)", 3306: "MySQL", 8080: "HTTP Alt"
}

def scan_port(ip, port, results):
    try:
        sock = socket.socket()
        sock.settimeout(1)
        if sock.connect_ex((ip, port)) == 0:
            results.append((port, common_ports.get(port, "Unknown")))
        sock.close()
    except:
        pass

def scan_ports(ip):
    console.print("\n[bold cyan]Scanning common open ports...[/bold cyan]")
    threads = []
    results = []
    for port in common_ports:
        t = threading.Thread(target=scan_port, args=(ip, port, results))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    table = Table(title="Open Ports", style="bold red")
    table.add_column("Port", style="cyan")
    table.add_column("Service", style="magenta")
    if results:
        for port, service in sorted(results):
            table.add_row(str(port), service)
    else:
        table.add_row("-", "No open common ports found")
    console.print(table)

# --- WAF / Firewall detection with UA manipulation ---
def detect_firewall(domain):
    waf_signatures = {
        "Cloudflare": ["cloudflare", "cf-ray", "__cfduid", "cf-cache-status"],
        "Sucuri": ["sucuri", "sucuri/cloudproxy", "x-sucuri"],
        "ModSecurity": ["mod_security", "modsecurity"],
        "AWS": ["aws", "awselb", "x-amzn"],
        "Incapsula": ["incap_ses", "incapsula"],
        "F5 BigIP": ["bigip", "f5", "x-waf"],
    }
    url = f"http://{domain}"
    headers_list = [
        {"User-Agent": "Mozilla/5.0"},
        {"User-Agent": "sqlmap/1.0"},
        {"User-Agent": "curl/7.68.0"},
        {"User-Agent": "Googlebot/2.1"},
    ]
    detected = set()
    try:
        for headers in headers_list:
            try:
                res_get = requests.get(url, headers=headers, timeout=5)
                res_post = requests.post(url, data={"test": "123"}, headers=headers, timeout=5)
            except:
                continue
            for waf, keywords in waf_signatures.items():
                for key in keywords:
                    key = key.lower()
                    # check GET headers, POST headers, GET body, POST body
                    if any(key in str(v).lower() for v in res_get.headers.values()) or \
                       any(key in str(v).lower() for v in res_post.headers.values()) or \
                       key in res_get.text.lower() or \
                       key in res_post.text.lower():
                        detected.add(waf)
                        break
        return list(detected) if detected else ["Tidak terdeteksi"]
    except Exception as e:
        return [f"Error: {e}"]

# --- Ping & Traceroute ---
def ping_test(domain):
    console.print("\n[cyan]Melakukan ping ke domain...[/cyan]")
    try:
        result = subprocess.run(
            ["ping", "-c", "4", domain],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        return result.stdout if result.returncode == 0 else result.stderr
    except Exception as e:
        return f"Gagal ping: {e}"

def traceroute_test(domain):
    console.print("\n[cyan]Melakukan traceroute ke domain...[/cyan]")
    try:
        cmd = ["traceroute", domain] if os.name != "nt" else ["tracert", domain]
        result = subprocess.run(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        return result.stdout if result.returncode == 0 else result.stderr
    except Exception as e:
        return f"Gagal traceroute: {e}"

# --- Detailed SSL cert info ---
def get_ssl_cert_info(domain):
    console.print("\n[cyan]Mengambil info SSL Certificate detail...[/cyan]")
    ctx = ssl.create_default_context()
    try:
        with ctx.wrap_socket(socket.socket(), server_hostname=domain) as s:
            s.settimeout(5)
            s.connect((domain, 443))
            cert = s.getpeercert()
            issuer = dict(x[0] for x in cert.get('issuer', []))
            return {
                "Issuer": issuer,
                "Valid From": cert.get('notBefore'),
                "Valid Until": cert.get('notAfter'),
                "Serial Number": cert.get('serialNumber', 'N/A')
            }
    except Exception as e:
        return {"Error": str(e)}

# --- Display helpers ---
def display_geoip(data):
    table = Table(title="GeoIP Information", style="bold green")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="magenta")
    for key in ['ip', 'city', 'region', 'country', 'org', 'loc', 'timezone']:
        table.add_row(key, str(data.get(key, 'N/A')))
    console.print(table)

def display_headers(code, headers):
    table = Table(title=f"HTTP Headers (Status: {code})", style="bold yellow")
    table.add_column("Header", style="cyan")
    table.add_column("Value", style="magenta")
    for k, v in headers.items():
        table.add_row(k, v)
    console.print(table)

def display_ssl(info):
    table = Table(title="SSL Certificate Info (Basic)", style="bold blue")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="magenta")
    for k, v in info.items():
        table.add_row(k, str(v))
    console.print(table)

def display_dns(dns_data):
    for rtype, records in dns_data.items():
        table = Table(title=f"{rtype} Records", style="bold green")
        table.add_column("Record", style="magenta")
        for r in records:
            table.add_row(r)
        console.print(table)

def display_whois(data):
    table = Table(title="WHOIS Information", style="bold blue")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="magenta")
    for k, v in data.items():
        table.add_row(k, str(v))
    console.print(table)

def main():
    banner()
    domain = console.input("[bold cyan]Masukkan domain atau IP: [/]").strip()
    ip = get_ip(domain)

    with Progress() as progress:
        task = progress.add_task("[green]Mengambil data...", total=10)

        geo = geoip(ip);                  progress.advance(task)
        code, headers = get_headers(domain); progress.advance(task)
        ssl_basic = ssl_info(domain);     progress.advance(task)
        dns_data = get_dns(domain);       progress.advance(task)
        whois_data = get_whois(domain);   progress.advance(task)
        scan_ports(ip);                   progress.advance(task)
        waf_result = detect_firewall(domain); progress.advance(task)
        ping_result = ping_test(domain);  progress.advance(task)
        trace_result = traceroute_test(domain); progress.advance(task)
        ssl_detail = get_ssl_cert_info(domain); progress.advance(task)

    console.print(Panel(f"[bold]Domain:[/] {domain}\n[bold]IP Address:[/] {ip}", title="Identitas", style="bold white"))
    display_geoip(geo)
    display_headers(code, headers)
    display_ssl(ssl_basic)
    display_dns(dns_data)
    display_whois(whois_data)

    # Firewall / WAF results
    fw_table = Table(title="Firewall / WAF Detection", style="bold yellow")
    fw_table.add_column("Detected Firewall", style="bold magenta")
    for waf in waf_result:
        fw_table.add_row(waf)
    console.print(fw_table)

    # Ping & traceroute
    console.print(Panel(ping_result, title="Ping Result", style="green"))
    console.print(Panel(trace_result, title="Traceroute Result", style="cyan"))

    # Detailed SSL certificate
    ssl_table = Table(title="SSL Certificate Info (Detailed)", style="bold blue")
    ssl_table.add_column("Key", style="yellow")
    ssl_table.add_column("Value", style="white")
    for k, v in ssl_detail.items():
        if isinstance(v, dict):
            for subk, subv in v.items():
                ssl_table.add_row(f"{k} – {subk}", str(subv))
        else:
            ssl_table.add_row(k, str(v))
    console.print(ssl_table)

    console.print(Panel("[green]Selesai![/] Data berhasil diambil.", style="bold green"))

if __name__ == "__main__":
    main()
