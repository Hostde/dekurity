import requests
import time
from datetime import datetime
from rich import print
from rich.panel import Panel
from rich.console import Console

konsol = Console()

def ambil_harga_crypto(nama_koin, mata_uang):
    url = "https://api.coingecko.com/api/v3/simple/price"
    parameter = {
        "ids": nama_koin.lower(),
        "vs_currencies": mata_uang.lower(),
        "include_24hr_change": "true"
    }
    respon = requests.get(url, params=parameter)
    if respon.status_code == 200:
        data = respon.json()
        if nama_koin in data:
            harga = data[nama_koin][mata_uang]
            perubahan = data[nama_koin].get(f"{mata_uang}_24h_change", 0)
            return harga, perubahan
        else:
            return None, None
    else:
        return None, None

def tampilkan_banner():
    judul = "[bold cyan]PENGECEK HARGA CRYPTO[/bold cyan]"
    deskripsi = (
        "[dim]Alat CLI sederhana untuk memantau harga crypto secara real-time\n"
        "Menggunakan API dari CoinGecko sebagai sumber data[/dim]\n\n"
        "[bold magenta]Pembuat:[/bold magenta] [italic cyan]Dekurity[/italic cyan]"
    )
    konsol.print(Panel.fit(f"{judul}\n\n{deskripsi}", border_style="cyan", padding=(1, 4)))

def utama():
    while True:
        tampilkan_banner()
        koin = konsol.input("[bold yellow]Masukkan nama koin[/bold yellow] (contoh: bitcoin): ").strip().lower()
        mata_uang = konsol.input("[bold yellow]Masukkan mata uang[/bold yellow] (contoh: idr, usd): ").strip().lower()

        print("\n[bold cyan]Mengambil data harga...[/bold cyan]")

        harga, perubahan = ambil_harga_crypto(koin, mata_uang)

        if harga is not None:
            waktu_sekarang = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            warna_perubahan = "green" if perubahan >= 0 else "red"
            info = (
                f"[bold]{koin.upper()}[/bold]  ([dim]{waktu_sekarang}[/dim])\n"
                f"Harga saat ini: [bold]{mata_uang.upper()} {harga:,.4f}[/bold]\n"
                f"Perubahan 24 jam: [{warna_perubahan}]{perubahan:+.2f}%[/{warna_perubahan}]"
            )
            konsol.print(Panel.fit(info, title=f"[cyan]Info {koin.upper()}[/cyan]", border_style="bright_magenta"))
        else:
            konsol.print(Panel("[bold red]Gagal mengambil data.[/bold red]\nPeriksa nama koin atau mata uang.", border_style="red"))

        ulangi = konsol.input("\n[bold]Ingin cek lagi? (y/n): [/bold]").strip().lower()
        if ulangi != 'y':
            print("\n[bold cyan]Terima kasih, sampai jumpa![/bold cyan]")
            break
        print()
        time.sleep(1)

if __name__ == "__main__":
    utama()
